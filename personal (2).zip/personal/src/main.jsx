import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.jsx';
import './fonts/fonts.css';
import './styles.css';

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
